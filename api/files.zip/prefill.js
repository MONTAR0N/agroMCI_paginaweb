// api/prefill.js
// GET /api/prefill?t=CLAVE
// Único lugar donde sale el config_id, y solo con clave válida.

const { buscarPorClave, evaluarClave, armarSetup, campo } = require("./_notion");

const espera = (ms) => new Promise(r => setTimeout(r, ms));

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "GET") {
    return res.status(405).json({ titulo: "Método no permitido", detalle: "" });
  }

  const clave = String((req.query && req.query.t) || "").trim().toUpperCase();

  // Freno simple contra prueba y error automatizada.
  await espera(400);

  if (!clave || clave.length < 6 || clave.length > 32) {
    return res.status(400).json({
      titulo: "Esta clave no está disponible",
      detalle: "Revise que esté bien escrita o pida una nueva al equipo de MCI."
    });
  }

  let page;
  try {
    page = await buscarPorClave(clave);
  } catch (e) {
    console.error("[prefill] error consultando Notion:", e.message);
    return res.status(500).json({
      titulo: "No pudimos verificar la clave",
      detalle: "Inténtelo de nuevo en unos minutos o escríbanos a contacto@agricolamci.cl."
    });
  }

  const veredicto = evaluarClave(page);
  if (!veredicto.ok) {
    return res.status(403).json({ titulo: veredicto.titulo, detalle: veredicto.detalle });
  }

  return res.status(200).json({
    appId: process.env.META_APP_ID,
    configId: process.env.META_CONFIG_ID,
    graphVersion: process.env.META_GRAPH_VERSION || "v23.0",
    cliente: campo(page, "Cliente") || "su empresa",
    setup: armarSetup(page)
  });
};
