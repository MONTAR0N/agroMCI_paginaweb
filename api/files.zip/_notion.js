// api/_notion.js
// Helper compartido. Los archivos que empiezan con "_" no se exponen como ruta en Vercel.

const NOTION_API = "https://api.notion.com/v1";
const NOTION_VERSION = "2022-06-28";

function headers() {
  return {
    "Authorization": "Bearer " + process.env.NOTION_TOKEN,
    "Notion-Version": NOTION_VERSION,
    "Content-Type": "application/json"
  };
}

// --- lectura de propiedades -------------------------------------------------

function texto(prop) {
  if (!prop) return "";
  if (prop.type === "title") return (prop.title || []).map(t => t.plain_text).join("").trim();
  if (prop.type === "rich_text") return (prop.rich_text || []).map(t => t.plain_text).join("").trim();
  if (prop.type === "email") return prop.email || "";
  if (prop.type === "url") return prop.url || "";
  if (prop.type === "phone_number") return prop.phone_number || "";
  if (prop.type === "select") return prop.select ? prop.select.name : "";
  if (prop.type === "date") return prop.date ? prop.date.start : "";
  if (prop.type === "number") return prop.number == null ? "" : String(prop.number);
  return "";
}

function campo(page, nombre) {
  return texto(page.properties ? page.properties[nombre] : null);
}

// --- búsqueda por clave -----------------------------------------------------

async function buscarPorClave(clave) {
  const r = await fetch(`${NOTION_API}/databases/${process.env.NOTION_DB_ONBOARDING}/query`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({
      page_size: 1,
      filter: { property: "Clave", rich_text: { equals: clave } }
    })
  });

  if (!r.ok) {
    const detalle = await r.text();
    throw new Error("Notion query falló: " + r.status + " " + detalle);
  }

  const data = await r.json();
  return (data.results && data.results.length) ? data.results[0] : null;
}

// --- escritura --------------------------------------------------------------

async function actualizarPagina(pageId, properties) {
  const r = await fetch(`${NOTION_API}/pages/${pageId}`, {
    method: "PATCH",
    headers: headers(),
    body: JSON.stringify({ properties })
  });
  if (!r.ok) {
    const detalle = await r.text();
    throw new Error("Notion update falló: " + r.status + " " + detalle);
  }
  return r.json();
}

const rt = (v) => ({ rich_text: [{ text: { content: String(v == null ? "" : v).slice(0, 1900) } }] });
const sel = (v) => ({ select: { name: v } });

// --- validación de estado y vigencia ---------------------------------------

const ESTADOS_VALIDOS = ["Pendiente", "En proceso"];

function evaluarClave(page) {
  if (!page) {
    return { ok: false, titulo: "Esta clave no está disponible",
             detalle: "Revise que esté bien escrita o pida una nueva al equipo de MCI." };
  }

  const estado = campo(page, "Estado");

  if (estado === "Completada") {
    return { ok: false, titulo: "Esta clave ya fue usada",
             detalle: "El número asociado ya está conectado. Si necesita conectar otro, pídanos una clave nueva." };
  }
  if (estado === "Revocada") {
    return { ok: false, titulo: "Esta clave fue anulada",
             detalle: "Escríbanos y le entregamos una nueva." };
  }
  if (!ESTADOS_VALIDOS.includes(estado)) {
    return { ok: false, titulo: "Esta clave no está disponible",
             detalle: "Revise que esté bien escrita o pida una nueva al equipo de MCI." };
  }

  const vence = campo(page, "Vence");
  if (vence) {
    const hoy = new Date().toISOString().slice(0, 10);
    if (vence < hoy) {
      return { ok: false, titulo: "Esta clave venció",
               detalle: "Escríbanos y le entregamos una nueva sin costo." };
    }
  }

  return { ok: true, page };
}

// --- prefill que se inyecta en el flujo de Meta -----------------------------

function armarSetup(page) {
  const setup = {};

  const business = {};
  const razon   = campo(page, "Razón social") || campo(page, "Cliente");
  const email   = campo(page, "Email");
  const sitio   = campo(page, "Sitio web");
  const fono    = campo(page, "Teléfono").replace(/[^0-9]/g, "");
  const calle   = campo(page, "Dirección");
  const comuna  = campo(page, "Comuna");
  const region  = campo(page, "Región");
  const postal  = campo(page, "Código postal");

  if (razon) business.name = razon;
  if (email) business.email = email;
  if (sitio) business.website = sitio;

  // Chile: código país 56. El número va sin el 56 adelante.
  if (fono) {
    const numero = fono.startsWith("56") ? fono.slice(2) : fono;
    business.phone = { code: 56, number: numero };
  }

  if (calle || comuna || region || postal) {
    business.address = {
      streetAddress1: calle,
      city: comuna,
      state: region,
      zipPostal: postal,
      country: "CL"
    };
  }

  if (Object.keys(business).length) setup.business = business;

  const phone = {};
  const display   = campo(page, "Display name");
  const categoria = campo(page, "Categoría");
  if (display)   phone.displayName = display;
  if (categoria) phone.category = categoria;
  if (Object.keys(phone).length) setup.phone = phone;

  return setup;
}

module.exports = {
  buscarPorClave, evaluarClave, armarSetup,
  actualizarPagina, campo, rt, sel
};
