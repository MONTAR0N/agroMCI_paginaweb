// api/onboarding.js
// POST /api/onboarding
// Body: { t, evento: "FINISH" | "CANCEL", code, waba_id, phone_number_id, business_id, detalle }
//
// Hace SOLO lo que tiene que ser rápido: el code de Meta vence en 30 segundos.
// El resto (subscribed_apps, register, Chatwoot) lo hace n8n, que no tiene límite de tiempo.

const { buscarPorClave, evaluarClave, actualizarPagina, campo, rt, sel } = require("./_notion");

function leerBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") { try { return JSON.parse(req.body); } catch (e) { return {}; } }
  return {};
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    return res.status(405).json({ error: "metodo_no_permitido" });
  }

  const body = leerBody(req);
  const clave = String(body.t || "").trim().toUpperCase();
  const evento = String(body.evento || "").toUpperCase();

  if (!clave) return res.status(400).json({ error: "falta_clave" });

  let page;
  try {
    page = await buscarPorClave(clave);
  } catch (e) {
    console.error("[onboarding] error consultando Notion:", e.message);
    return res.status(500).json({ error: "notion" });
  }

  const veredicto = evaluarClave(page);
  if (!veredicto.ok) return res.status(403).json({ error: "clave_invalida" });

  const pageId = page.id;
  const cliente = campo(page, "Cliente");

  // ---- Abandono o error reportado: se registra y se termina ----------------
  if (evento === "CANCEL") {
    const paso = (body.detalle && (body.detalle.current_step || body.detalle.error_message)) || "desconocido";
    try {
      await actualizarPagina(pageId, {
        "Notas": rt(`[${new Date().toISOString()}] Flujo interrumpido en: ${paso}`)
      });
    } catch (e) {
      console.error("[onboarding] no se pudo registrar el corte:", e.message);
    }
    return res.status(204).end();
  }

  // ---- Flujo completado ----------------------------------------------------
  if (evento !== "FINISH") return res.status(400).json({ error: "evento_desconocido" });

  const code = String(body.code || "");
  const wabaId = String(body.waba_id || "");
  const phoneNumberId = String(body.phone_number_id || "");
  const businessId = String(body.business_id || "");

  if (!code || !wabaId || !phoneNumberId) {
    return res.status(400).json({ error: "faltan_datos" });
  }

  // 1. Canjear el code por el business token (esto es lo urgente)
  const version = process.env.META_GRAPH_VERSION || "v23.0";
  let businessToken;
  try {
    const url = new URL(`https://graph.facebook.com/${version}/oauth/access_token`);
    url.searchParams.set("client_id", process.env.META_APP_ID);
    url.searchParams.set("client_secret", process.env.META_APP_SECRET);
    url.searchParams.set("code", code);

    const r = await fetch(url.toString(), { method: "GET" });
    const data = await r.json();

    if (!r.ok || !data.access_token) {
      console.error("[onboarding] canje de code falló:", JSON.stringify(data));
      return res.status(502).json({ error: "canje_fallido" });
    }
    businessToken = data.access_token;
  } catch (e) {
    console.error("[onboarding] error en el canje:", e.message);
    return res.status(502).json({ error: "canje_fallido" });
  }

  // 2. Dejar constancia en Notion antes de delegar
  try {
    await actualizarPagina(pageId, {
      "Estado": sel("En proceso"),
      "WABA ID": rt(wabaId),
      "Phone Number ID": rt(phoneNumberId),
      "Business ID": rt(businessId),
      "Business token": rt(businessToken)
    });
  } catch (e) {
    console.error("[onboarding] no se pudo escribir en Notion:", e.message);
    // Se sigue igual: el token ya existe y n8n puede terminar el trabajo.
  }

  // 3. Delegar a n8n. El webhook debe responder de inmediato ("Respond: Immediately"),
  //    porque el register del número puede demorar hasta dos minutos.
  try {
    const r = await fetch(process.env.N8N_ONBOARDING_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-MCI-Secret": process.env.N8N_SHARED_SECRET
      },
      body: JSON.stringify({
        notion_page_id: pageId,
        cliente,
        clave,
        waba_id: wabaId,
        phone_number_id: phoneNumberId,
        business_id: businessId,
        business_token: businessToken,
        graph_version: version
      })
    });
    if (!r.ok) console.error("[onboarding] n8n respondió", r.status);
  } catch (e) {
    console.error("[onboarding] no se pudo avisar a n8n:", e.message);
    return res.status(502).json({ error: "n8n" });
  }

  return res.status(200).json({ ok: true });
};
